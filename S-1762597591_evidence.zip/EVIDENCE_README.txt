Evidence package for session: S-1762597591
Generated: Sat Nov 8 15:56:32 2025

Contents:
- meta.json : timestamped event log and classifier output
- payload_*.bin : quarantined payload captures (sha256 recorded in meta.json)

Integrity:
- Each payload file includes sha256 and size in meta.json.
- verify_meta_integrity.py was run and returned: All payload entries verified OK.

Safety notes:
- Payloads are quarantined, not executed.
- All tests were run locally on 127.0.0.1.

Contact: <Ravikiran.U> (for follow-ups)